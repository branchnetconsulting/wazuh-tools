This offline SIEM agent deployment bundle contains:

Windows SIEM suite deployment powershell script from BNC GitHub repo "wazuh-tools" as of 7/22/2020
NuGet 2.8.5.208
Wazuh Agent 3.13.1
Osquery 4.4.0
Sysmon 11.11
Starting Sysmon config file from BNC GitHub repo "wazuh-tools" as of 7/22/2020

To do an offline installation, open a command shell with "Run as Administrator" into the directory where this bundle is unzipped and run:

PowerShell.exe -ExecutionPolicy Bypass -File ./deploy-wazuh-windows-agent-suite.ps1 -WazuhMgr "***YOUR_WAZUH_MANAGER***" -WazuhRegPass "***YOUR_REGISTRATION_PASSWORD***" -Local

For other parameters, see the top of the powershell file.


